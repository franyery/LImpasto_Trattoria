﻿import os

TEMPLATE_DIR = 'templates'
cambios = {
    'main.home': 'home.home',
    'main.dashboard': 'home.dashboard',
    'main.clientes': 'cliente.clientes',
    'main.nuevo_cliente': 'clientes.nuevo',
    'main.editar_cliente': 'cliente.editar_cliente',
    'main.eliminar_cliente': 'cliente.eliminar_cliente',
    'main.mesas': 'mesa.mesas',
    'main.editar_mesa': 'mesa.editar_mesa',
    'main.eliminar_mesa': 'mesa.eliminar_mesa',
    'main.liberar_mesa': 'mesa.liberar_mesa',
    'main.menu': 'menu.menu',
    'main.editar_plato': 'menu.editar_plato',
    'main.eliminar_plato': 'menu.eliminar_plato',
    'main.nueva_categoria': 'menu.nueva_categoria',
    'main.reservaciones': 'reservacion.reservaciones',
    'main.nueva_reservacion': 'reservacion.nueva_reservacion',
    'main.eliminar_reserva': 'reservacion.eliminar_reserva',
    'main.facturas': 'factura.facturas',
    'main.nueva_factura': 'factura.nueva_factura',
    'main.facturar_directo': 'factura.facturar_directo'
}

for root, dirs, files in os.walk(TEMPLATE_DIR):
    for file in files:
        if file.endswith('.html'):
            file_path = os.path.join(root, file)
            with open(file_path, 'r', encoding='utf-8') as f:
                content = f.read()
            nuevo_contenido = content
            for antiguo, nuevo in cambios.items():
                nuevo_contenido = nuevo_contenido.replace(antiguo, nuevo)
            if nuevo_contenido != content:
                with open(file_path, 'w', encoding='utf-8') as f:
                    f.write(nuevo_contenido)
                print(f'Actualizado: {file_path}')
print('\n¡Enlaces de L’Impasto listos!')
